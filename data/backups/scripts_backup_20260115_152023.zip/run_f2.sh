#!/bin/bash

# ================= 核心配置区域 =================
# 1. 你的主页链接
URL="https://www.douyin.com/user/MS4wLjABAAAA38DSB9C8X7wWA5eJ1ID_wS0BvleFkgIn3OHGY_HGGsIntA8yXhg2lzYrc9ee2N5P"

# 2. Bark 配置
BARK_KEY="umdMsu6YaFmC6qwV6CPcw"

# 3. 路径配置 (⚠️ 精确匹配 F2 的目录结构)
TEMP_PATH="/mnt/nas_home/douyin/temp_staging"
SOURCE_DIR="${TEMP_PATH}/douyin/like/Ch1"
FINAL_PATH="/mnt/nas_home/douyin/like/Ch1"

# 4. F2 和日志路径
F2_CMD="/root/.local/bin/f2"
LOG_FILE="/etc/docker/douyin_download/f2_daily.log"
# ===========================================

# --- 0. 环境准备 ---
echo "【任务启动】 $(date)" >> "$LOG_FILE"

# 清空并重建中转区
rm -rf "$TEMP_PATH"
mkdir -p "$TEMP_PATH"
mkdir -p "$FINAL_PATH"

# --- 1. 执行下载 ---
# 下载 50 个到中转区
$F2_CMD dy -M like -u "$URL" -o 50 >> "$LOG_FILE" 2>&1

# --- 2. 检查是否有新文件 ---
if [ -d "$SOURCE_DIR" ] && [ "$(ls -A "$SOURCE_DIR")" ]; then
    echo ">>> 检测到下载数据，开始清洗命名..." >> "$LOG_FILE"

    # --- 3. 文件名清洗 (原地修改) ---
    find "$SOURCE_DIR" -type f -name "*_video.mp4" | while read -r file; do
        mv "$file" "${file/_video.mp4/.mp4}"
    done
    find "$SOURCE_DIR" -type f -name "*_cover.*" | while read -r file; do
        mv "$file" "${file/_cover./.}"
    done

    # --- 4. 文件夹搬运与智能统计 (核心修改) ---
    echo ">>> 清洗完毕，开始智能比对移动..." >> "$LOG_FILE"
    
    NEW_COUNT=0  # 初始化本次新增计数器
    
    # 遍历 SOURCE_DIR 下所有的子文件夹
    # 使用 glob 通配符，如果包含空格也能正确处理
    for folder_path in "$SOURCE_DIR"/*; do
        # 确保它确实是一个目录
        if [ -d "$folder_path" ]; then
            # 获取文件夹的名字 (例如: "2023-10-01_某某视频")
            folder_name=$(basename "$folder_path")
            
            # 判断最终目录是否已经存在这个名字
            if [ -d "$FINAL_PATH/$folder_name" ]; then
                # 如果存在，则是重复的，不移动，也不计数
                echo "  [跳过] 已存在: $folder_name" >> "$LOG_FILE"
            else
                # 如果不存在，则移动，并计数 +1
                mv "$folder_path" "$FINAL_PATH/"
                ((NEW_COUNT++))
                echo "  [入库] 新增: $folder_name" >> "$LOG_FILE"
            fi
        fi
    done

    # 统计大库当前总数
    TOTAL_COUNT=$(find "$FINAL_PATH" -mindepth 1 -maxdepth 1 -type d | wc -l)
    
    echo ">>> 处理完成。本次新增: $NEW_COUNT 个，大库总存量: $TOTAL_COUNT 个" >> "$LOG_FILE"

    # --- 5. 发送 Bark 通知 ---
    echo ">>> 发送通知..." >> "$LOG_FILE"
    
    # 如果新增为 0，通知稍微改一下语气
    if [ "$NEW_COUNT" -eq 0 ]; then
        TITLE="F2 任务结束 (无新增)"
        BODY="本次下载的视频已全部存在于库中，无需更新。当前库存：$TOTAL_COUNT"
    else
        TITLE="F2 新增成功入库"
        BODY="老板，已搬运 $NEW_COUNT 个新视频。当前库存总数：$TOTAL_COUNT。"
    fi
    
    # 注意：URL参数中如果包含空格或中文需要转码，这里主要靠 body 传参，curl --data-urlencode 更稳，
    # 但为了保持你原脚本风格，直接拼接变量即可 (只要变量不含特殊中断字符)
    curl -s -X POST "https://api.day.app/$BARK_KEY" \
        -d "title=$TITLE" \
        -d "body=$BODY" \
        -d "isArchive=1" \
        -d "group=F2下载助手" \
        -d "icon=https://f2.wiki/f2-logo-with-shadow.png" \
        >> "$LOG_FILE" 2>&1

else
    echo ">>> 本次没有下载到任何内容 (F2未拉取到数据)。" >> "$LOG_FILE"
fi

# --- 6. 收尾清理 ---
rm -rf "$TEMP_PATH"

echo "【任务完成】" >> "$LOG_FILE"
echo "--------------------------------" >> "$LOG_FILE"
